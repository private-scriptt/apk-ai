const axios = require('axios')

module.exports = {
  help: ['tiktok', 'tt'],
  tags: ['search'],
  command: /^(tiktok|tt)$/i,

  run: async (m, { conn, args }) => {
    try {
      let url = args[0]
      if (!url) return m.reply('Masukkan link TikTok!')

      if (!/tiktok.com/.test(url)) {
        return m.reply('Link tidak valid!')
      }

      // ⏳ REACTION LOADING
      await conn.sendMessage(m.chat, {
        react: { text: '⏳', key: m.key }
      })

      let { data } = await axios.get('https://tikwm.com/api/', {
        params: { url }
      })

      if (!data || !data.data) {
        return m.reply('Gagal mengambil video.')
      }

      let res = data.data

      let caption = `乂 *TIKTOK DOWNLOADER*

• Author : ${res.author.nickname}
• Likes  : ${res.digg_count}
• Comment: ${res.comment_count}
• Share  : ${res.share_count}

📝 Caption:
${res.title || '-'}`

      // kirim video
      await conn.sendMessage(m.chat, {
        video: { url: res.play },
        caption
      }, { quoted: m })

      // ✅ DONE
      await conn.sendMessage(m.chat, {
        react: { text: '✅', key: m.key }
      })

    } catch (e) {
      console.error(e)

      await conn.sendMessage(m.chat, {
        react: { text: '❌', key: m.key }
      })

      m.reply('Terjadi kesalahan saat download.')
    }
  }
}