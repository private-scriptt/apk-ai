const axios = require('axios')

// decode HTML entity
function decodeHTML(str) {
   return str
      .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(dec))
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
}

// bersihin HTML
function cleanHTML(html) {
   return decodeHTML(
      html
         .replace(/<script[\s\S]*?<\/script>/gi, '')
         .replace(/<style[\s\S]*?<\/style>/gi, '')
         .replace(/<!--[\s\S]*?-->/g, '')
         .replace(/<[^>]+>/g, '\n')
   )
}

// deteksi musik
function isMusic(text) {
   return /dj|lagu|musik|tiktok|remix|mp3/i.test(text)
}

// =====================
// 🧮 KALKULATOR
// =====================
function kalkulator(expr) {
   try {
      if (!/^[0-9+\-*/().\s]+$/.test(expr)) return null
      let hasil = Function(`"use strict"; return (${expr})`)()
      return hasil
   } catch {
      return null
   }
}

// =====================
// 🌍 TRANSLATE
// =====================
async function translate(text, to = 'en') {
   try {
      let { data } = await axios.get(
         'https://translate.googleapis.com/translate_a/single',
         {
            params: {
               client: 'gtx',
               sl: 'auto',
               tl: to,
               dt: 't',
               q: text
            }
         }
      )

      return data[0].map(v => v[0]).join('')
   } catch {
      return null
   }
}

module.exports = {
   help: ['ddg'],
   tags: ['search'],
   run: async (m, { conn, text }) => {

      if (!text) return m.reply('🚩 Masukkan query!')

      try {

         // =====================
         // 🧮 AUTO KALKULATOR
         // =====================
         if (/^[0-9+\-*/().\s]+$/.test(text)) {
            let hasil = kalkulator(text)
            if (hasil !== null) {
               return m.reply(`🧮 *KALKULATOR*\n\n${text} = ${hasil}`)
            }
         }

         // =====================
         // 🌍 AUTO TRANSLATE
         // =====================
         if (/^translate|terjemahkan|ubah/i.test(text)) {

            let q = text.replace(/^translate|terjemahkan|ubah/i, '').trim()
            if (!q) return m.reply('🚩 Masukkan teks!')

            let hasil = await translate(q, 'en')

            if (!hasil) return m.reply('🚩 Gagal translate.')

            return m.reply(`🌍 *TRANSLATE*\n\n${hasil}`)
         }

         let lower = text.toLowerCase()
         let isImage = lower.startsWith('gambar')
         let isResep = lower.startsWith('resep')
         let isMusicMode = isMusic(text)

         let query = text.replace(/^(gambar|resep)\s*/i, '').trim()

         m.reply('🔄 Sedang mencari...')

         // =====================
         // 🍽️ RESEP
         // =====================
         if (isResep) {

            let { data: html } = await axios.get(
               'https://duckduckgo.com/html/?q=' + encodeURIComponent(query + ' resep masakan'),
               { headers: { 'User-Agent': 'Mozilla/5.0' } }
            )

            let links = [...html.matchAll(/uddg=(.*?)&/g)]
               .map(v => decodeURIComponent(v[1]))

            let found = false

            for (let link of links.slice(0, 3)) {

               try {
                  let { data: page } = await axios.get(link)

                  let clean = cleanHTML(page)

                  let lines = clean.split('\n')
                     .map(v => v.trim())
                     .filter(v => v.length > 3)

                  let bahan = []
                  let langkah = []

                  lines.forEach(v => {
                     if (/gram|kg|ml|sdm|sdt|butir|siung|buah/i.test(v) && v.length < 80) bahan.push(v)
                     if (/goreng|rebus|tumis|aduk|campur|panaskan|masak/i.test(v) && v.length > 20) langkah.push(v)
                  })

                  bahan = [...new Set(bahan)].slice(0, 10)
                  langkah = [...new Set(langkah)].slice(0, 10)

                  if (bahan.length && langkah.length) {

                     let img = page.match(/property="og:image" content="(.*?)"/)?.[1]

                     let teks = `🍽️ *RESEP ${query.toUpperCase()}*\n\n`

                     teks += `🧂 *Bahan:*\n`
                     bahan.forEach((b, i) => teks += `${i + 1}. ${b}\n`)

                     teks += `\n👨‍🍳 *Cara Memasak:*\n`
                     langkah.forEach((l, i) => teks += `${i + 1}. ${l}\n`)

                     await conn.sendMessage(m.chat, {
                        image: { url: img || 'https://via.placeholder.com/300' },
                        caption: teks
                     }, { quoted: m })

                     found = true
                     break
                  }

               } catch {}
            }

            if (!found) m.reply('🚩 Resep tidak ditemukan.')
         }

         // =====================
         // 🖼️ GAMBAR HD
         // =====================
         else if (isImage) {

            let { data: html } = await axios.get(
               'https://duckduckgo.com/?q=' + encodeURIComponent(query),
               { headers: { 'User-Agent': 'Mozilla/5.0' } }
            )

            let vqd = html.match(/vqd="(.*?)"/)?.[1]
            if (!vqd) return m.reply('🚩 Gagal ambil gambar.')

            let { data } = await axios.get('https://duckduckgo.com/i.js', {
               params: { q: query, vqd },
               headers: { 'User-Agent': 'Mozilla/5.0' }
            })

            let imgs = data.results
               .filter(v => v.image)
               .slice(0, 3)

            for (let img of imgs) {
               await conn.sendMessage(m.chat, {
                  image: { url: img.image },
                  caption: `🖼️ ${query}`
               }, { quoted: m })
            }
         }

         // =====================
         // 🎧 MUSIK (FIX TITLE)
         // =====================
         else if (isMusicMode) {

            let { data: html } = await axios.get(
               'https://duckduckgo.com/html/?q=' + encodeURIComponent(query + ' site:youtube.com'),
               { headers: { 'User-Agent': 'Mozilla/5.0' } }
            )

            let results = [...html.matchAll(/result__a.*?href="(.*?)".*?>(.*?)<\/a>/g)]

            let list = []
            for (let r of results) {
               let url = decodeURIComponent(r[1])
               let title = decodeHTML(r[2].replace(/<[^>]+>/g, ''))

               if (url.includes('youtube.com/watch')) {
                  list.push({ url, title })
               }
            }

            list = list.filter((v, i, a) =>
               a.findIndex(t => t.url === v.url) === i
            ).slice(0, 15)

            if (!list.length) return m.reply('🚩 Musik tidak ditemukan.')

            let firstThumb = `https://img.youtube.com/vi/${list[0].url.split('v=')[1]}/maxresdefault.jpg`

            let teks = `🎧 *HASIL DJ / MUSIK*\n\n`

            list.forEach((v, i) => {
               teks += `${i + 1}. ${v.title}\n${v.url}\n\n`
            })

            await conn.sendMessage(m.chat, {
               image: { url: firstThumb },
               caption: teks
            }, { quoted: m })
         }

         // =====================
         // 🔎 TEXT SUPER CLEAN (GABUNG JADI 1)
         // =====================
         else {

            let { data: html } = await axios.get(
               'https://duckduckgo.com/html/?q=' + encodeURIComponent(query),
               { headers: { 'User-Agent': 'Mozilla/5.0' } }
            )

            let snippets = [...html.matchAll(/result__snippet.*?>(.*?)<\/a>/g)]

            let hasil = []

            for (let s of snippets.slice(0, 5)) {
               let txt = decodeHTML(s[1].replace(/<[^>]+>/g, ''))
               if (txt.length > 40 && !txt.match(/iklan|ads|login|daftar/i)) {
                  hasil.push(txt)
               }
            }

            if (!hasil.length) return m.reply('🚩 Tidak ditemukan.')

            let final = hasil.join(' ')
               .replace(/\s+/g, ' ')
               .trim()

            m.reply(`🔎 *${query}*\n\n${final}`)
         }

      } catch (e) {
         console.error(e)
         m.reply('🚩 Error saat proses.')
      }
   }
}