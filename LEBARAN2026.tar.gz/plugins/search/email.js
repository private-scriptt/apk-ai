process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"

const nodemailer = require('nodemailer')
const imaps = require('imap-simple')
const config = require(process.cwd() + '/email.json')

// 🔥 CLEAN EMAIL
function cleanEmail(html) {
  let text = html

  text = text
    .replace(/=\r?\n/g, '')
    .replace(/=([A-F0-9]{2})/gi, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    )

  text = text.replace(/\[EMAIL_BUTTON:[^\]]+\]/gi, '')

  text = text.replace(/\[([^\]]+)\]\((.*?)\)/g, '$1')

  text = text
    .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(dec))
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')

  text = text
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, '\n')

  text = text
    .replace(/â/g, "'")
    .replace(/â/g, "-")
    .replace(/â|â/g, '"')
    .replace(/Â/g, '')

  text = text
    .replace(/This is what you wrote[\s\S]*/i, '')
    .replace(/Replies to this email won.?t be monitored.*/i, '')

  let lines = text.split('\n')
    .map(v => v.trim())
    .filter(v => v.length > 5)

  lines = [...new Set(lines)]

  return lines.join('\n')
    .replace(/\n{2,}/g, '\n')
    .replace(/\s{2,}/g, ' ')
    .trim()
}

// 🔁 WAIT BALASAN
async function waitForReply(conn, m, imapConfig) {
  try {
    const connection = await imaps.connect(imapConfig)
    await connection.openBox('INBOX')

    let found = false
    let start = Date.now()

    while (!found && Date.now() - start < 300000) { // max 5 menit
      let messages = await connection.search(['UNSEEN'], {
        bodies: ['TEXT'],
        markSeen: true
      })

      if (messages.length) {
        let last = messages[messages.length - 1]
        let body = last.parts[0].body
        let clean = cleanEmail(body)

        await conn.sendMessage(m.chat, {
          text: `乂 *BALASAN WHATSAPP*\n\n${clean.slice(0, 1000)}`
        }, { quoted: m })

        await conn.sendMessage(m.chat, {
          react: { text: '✅', key: m.key }
        })

        found = true
      } else {
        await new Promise(resolve => setTimeout(resolve, 10000)) // delay 10 detik
      }
    }

    if (!found) {
      await conn.sendMessage(m.chat, {
        react: { text: '❌', key: m.key }
      })
      m.reply('Tidak ada balasan dalam 5 menit.')
    }

    connection.end()

  } catch (e) {
    console.log(e)

    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })

    m.reply('Gagal cek balasan.')
  }
}

module.exports = {
  help: ['fix'],
  tags: ['owner'],
  command: /^email$/i,

  run: async (m, { conn, args }) => {
    try {
      let text = args.join(' ')
      if (!text) return m.reply('Masukkan isi email!')

      // ⏳ REACTION
      await conn.sendMessage(m.chat, {
        react: { text: '⏳', key: m.key }
      })

      // 📤 KIRIM EMAIL
      let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: config.email,
          pass: config.pass
        }
      })

      await transporter.sendMail({
        from: config.email,
        to: 'support@support.whatsapp.com',
        subject: 'WhatsApp Support',
        text
      })

      // 📥 IMAP CONFIG
      const imapConfig = {
        imap: {
          user: config.email,
          password: config.pass,
          host: 'imap.gmail.com',
          port: 993,
          tls: true,
          authTimeout: 10000
        }
      }

      // 🔥 LANGSUNG TUNGGU BALASAN (TANPA TIMEOUT)
      waitForReply(conn, m, imapConfig)

    } catch (e) {
      console.error(e)

      await conn.sendMessage(m.chat, {
        react: { text: '❌', key: m.key }
      })

      m.reply('Gagal kirim email.')
    }
  }
}