const fs = require('fs')
const pLimit = require('p-limit')

module.exports = {
  help: ['cekbio'],
  tags: ['search'],
  command: /^cekban$/i,

  run: async (m, { conn, args }) => {
    try {
      let numbers = []

      // FILE
      if (m.quoted && m.quoted.mimetype === 'text/plain') {
        let buffer = await m.quoted.download()
        let file = buffer.toString()
        numbers = file.match(/\+?\d{8,15}/g) || []
      } 
      // MANUAL
      else if (args.length) {
        let raw = args.join(' ')
        numbers = raw.match(/\+?\d{8,15}/g) || []
      }

      if (!numbers.length) return m.reply('Masukkan nomor / reply file txt')

      // FORMAT
      numbers = numbers.map(v => '+' + v.replace(/[^0-9]/g, ''))
      numbers = [...new Set(numbers)]
      numbers = numbers.filter(v => v.length >= 10 && v.length <= 16)

      let normal = []
      let ringan = []
      let spam = []
      let mati = []

      let total = numbers.length

      await conn.sendMessage(m.chat, {
        react: { text: '⏳', key: m.key }
      })

      const limit = pLimit(3)
      let count = 0

      let msg = await conn.sendMessage(m.chat, {
        text: `Progress: 0/${total}`
      }, { quoted: m })

      await Promise.all(numbers.map(num => limit(async () => {
        let clean = num.replace(/[^0-9]/g, '')
        let jid = clean + '@s.whatsapp.net'

        let status = {
          exists: false,
          hasPP: false,
          hasBio: false,
          isBusiness: false,
          isBanned: false,
          isDeleted: false,
          isRestricted: false,
          isActive: false,
          lastSeen: null,
          online: false,
          quality: 0
        }
        
        let detectionScore = 0
        let banScore = 0
        let activeScore = 0

        try {
          // LAYER 1: WHATSAPP REGISTRATION CHECK
          let res = await conn.onWhatsApp(jid)
          
          if (!res || res.length === 0) {
            mati.push(`🔴 ${num}`)
            return
          }
          
          status.exists = true
          
          if (res[0]?.isBusiness) {
            status.isBusiness = true
            detectionScore += 2
          }
          
          // LAYER 2: PROFILE PICTURE DEEP SCAN
          try {
            let pp = await conn.profilePictureUrl(jid, 'image')
            if (pp && pp.length > 0) {
              status.hasPP = true
              status.quality += 30
              activeScore += 25
              
              if (pp.includes('cloudfront') || pp.includes('whatsapp')) {
                status.quality += 10
                activeScore += 15
              }
            }
          } catch (err) {
            const errorMsg = err.message || ''
            
            if (errorMsg.includes('404')) {
              status.isDeleted = true
              banScore += 100
            } else if (errorMsg.includes('401')) {
              status.isBanned = true
              banScore += 100
            } else if (errorMsg.includes('403')) {
              status.isRestricted = true
              banScore += 90
            } else if (errorMsg.includes('405')) {
              status.isBanned = true
              banScore += 95
            } else if (errorMsg.includes('406')) {
              status.isBanned = true
              banScore += 95
            } else if (errorMsg.includes('429')) {
              status.isRestricted = true
              banScore += 80
            } else {
              detectionScore += 2
            }
          }
          
          // LAYER 3: STATUS/BIO DEEP ANALYSIS
          try {
            let st = await conn.fetchStatus(jid)
            let bio = st?.status || ''
            let timestamp = st?.timestamp
            
            if (bio && bio.length > 0) {
              status.hasBio = true
              status.quality += 25
              activeScore += 30
              
              if (timestamp && (Date.now() - timestamp) < 7 * 24 * 60 * 60 * 1000) {
                status.quality += 20
                activeScore += 40
              }
              
              if (timestamp && (Date.now() - timestamp) < 24 * 60 * 60 * 1000) {
                activeScore += 60
              }
              
              const spamIndicators = [
                { pattern: /jual|beli|murah|promo|diskon|shop|store|grosir|dropship|reseller|cod|order|pesan/i, weight: 15 },
                { pattern: /wa\.me|https?:\/\/|bit\.ly|tinyurl|shorturl|linktr\.ee/i, weight: 20 },
                { pattern: /telegram|line|instagram|fb|facebook|twitter|tiktok|youtube/i, weight: 15 },
                { pattern: /\+\d{10,}/, weight: 15 },
                { pattern: /[!@#$%^&*()]{5,}/, weight: 10 },
                { pattern: /^[a-zA-Z0-9]{1,5}$/, weight: 10 },
                { pattern: /^\d+$/, weight: 15 }
              ]
              
              for (let ind of spamIndicators) {
                if (ind.pattern.test(bio)) {
                  detectionScore += ind.weight
                }
              }
              
              if (bio.length < 5) detectionScore += 10
              if (bio.length > 200) detectionScore += 15
              if (bio.length === 0) detectionScore += 20
              
            } else {
              detectionScore += 15
            }
            
          } catch (err) {
            const errorMsg = err.message || ''
            
            if (errorMsg.includes('401')) {
              status.isBanned = true
              banScore += 100
            } else if (errorMsg.includes('403')) {
              status.isRestricted = true
              banScore += 90
            } else if (errorMsg.includes('404')) {
              status.isDeleted = true
              banScore += 100
            } else {
              detectionScore += 25
            }
          }
          
          // LAYER 4: PRESENCE & ACTIVITY DEEP SCAN - FOKUS AKTIF
          try {
            let presence = await conn.presenceSubscribe(jid)
            
            if (presence) {
              if (presence.lastKnownPresence) {
                status.lastSeen = presence.lastKnownPresence
                
                if (presence.lastKnownPresence === 'online') {
                  status.online = true
                  status.isActive = true
                  status.quality += 80
                  activeScore += 100
                } else if (presence.lastKnownPresence === 'available') {
                  status.isActive = true
                  status.quality += 50
                  activeScore += 70
                } else if (presence.lastKnownPresence === 'composing') {
                  status.isActive = true
                  status.quality += 70
                  activeScore += 90
                } else if (presence.lastKnownPresence === 'recently') {
                  activeScore += 40
                }
              }
              
              if (presence.lastSeen) {
                const lastSeenTime = presence.lastSeen
                const hoursSince = (Date.now() - lastSeenTime) / (1000 * 60 * 60)
                
                if (hoursSince < 1) {
                  status.isActive = true
                  activeScore += 100
                  status.quality += 60
                } else if (hoursSince < 6) {
                  activeScore += 80
                  status.quality += 50
                } else if (hoursSince < 12) {
                  activeScore += 60
                  status.quality += 40
                } else if (hoursSince < 24) {
                  activeScore += 40
                  status.quality += 30
                } else if (hoursSince < 72) {
                  activeScore += 20
                  status.quality += 15
                } else if (hoursSince < 168) {
                  activeScore += 10
                  status.quality += 5
                }
              }
            }
          } catch (e) {
            detectionScore += 5
          }
          
          // LAYER 5: GROUP ACTIVITY DETECTION
          try {
            let groups = await conn.groupFetchAllParticipating?.()
            if (groups) {
              let groupCount = 0
              for (let groupId in groups) {
                if (groups[groupId].participants?.some(p => p.id === jid)) {
                  groupCount++
                  if (groupCount >= 3) {
                    status.isActive = true
                    activeScore += 50
                    break
                  }
                }
              }
              if (groupCount > 0) {
                activeScore += groupCount * 10
              }
            }
          } catch (e) {
            // Skip
          }
          
          // ULTIMATE BANNED DETECTION
          const isUltimateBanned = banScore >= 90 || 
                                   status.isBanned || 
                                   status.isDeleted || 
                                   status.isRestricted ||
                                   (detectionScore >= 70 && !status.hasPP && !status.hasBio)
          
          if (isUltimateBanned) {
            spam.push(`🟠 ${num}`)
            return
          }
          
          // PRIORITAS UTAMA: DETEKSI WA AKTIF
          const isActiveWA = status.online || 
                             status.isActive || 
                             activeScore >= 60 ||
                             (status.hasPP && status.hasBio && activeScore >= 40) ||
                             (status.lastSeen === 'online') ||
                             (status.lastSeen === 'available') ||
                             (status.lastSeen === 'composing')
          
          // FINAL CLASSIFICATION DENGAN FOKUS AKTIF
          const totalQuality = status.quality - detectionScore + activeScore
          
          if (isActiveWA && totalQuality >= 50 && status.hasPP && status.hasBio) {
            normal.push(`🟢 ${num}`)
          } else if (isActiveWA && totalQuality >= 30) {
            normal.push(`🟢 ${num}`)
          } else if (totalQuality >= 60 && status.hasPP && status.hasBio) {
            normal.push(`🟢 ${num}`)
          } else if (totalQuality >= 40 && status.hasPP) {
            ringan.push(`🟡 ${num}`)
          } else if (totalQuality >= 20) {
            ringan.push(`🟡 ${num}`)
          } else if (totalQuality > -30) {
            spam.push(`🟠 ${num}`)
          } else {
            spam.push(`🟠 ${num}`)
          }

        } catch (err) {
          const errorMsg = err.message || ''
          
          if (errorMsg.includes('401') || errorMsg.includes('403') || 
              errorMsg.includes('404') || errorMsg.includes('405') || 
              errorMsg.includes('406') || errorMsg.includes('410')) {
            spam.push(`🟠 ${num}`)
          } else if (errorMsg.includes('429')) {
            spam.push(`🟠 ${num}`)
          } else if (errorMsg.includes('500') || errorMsg.includes('502') || errorMsg.includes('503')) {
            mati.push(`🔴 ${num}`)
          } else {
            mati.push(`🔴 ${num}`)
          }
        }

        count++

        if (count % 5 === 0 || count === total) {
          await conn.sendMessage(m.chat, {
            text: `Progress: ${count}/${total}`,
            edit: msg.key
          })
        }

      })))

      let summary = `
乂 HASIL CEK NOMOR

Total : ${total}
🟢 Normal : ${normal.length}
🟡 Ringan : ${ringan.length}
🟠 Spam / Banned : ${spam.length}
🔴 Mati : ${mati.length}
`.trim()

      let hasil = [
        ...normal,
        ...ringan,
        ...spam,
        ...mati
      ].join('\n')

      let fileName = `hasil_${Date.now()}.txt`
      fs.writeFileSync(fileName, hasil)

      await conn.sendMessage(m.chat, {
        document: fs.readFileSync(fileName),
        fileName,
        mimetype: 'text/plain',
        caption: summary
      }, { quoted: m })

      fs.unlinkSync(fileName)

      await conn.sendMessage(m.chat, {
        text: '‎',
        edit: msg.key
      })

      await conn.sendMessage(m.chat, {
        react: { text: '✅', key: m.key }
      })

    } catch (e) {
      console.log(e)

      await conn.sendMessage(m.chat, {
        react: { text: '❌', key: m.key }
      })

      m.reply('Error cekban.')
    }
  }
}