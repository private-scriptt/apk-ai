const TIMEOUT = 2 * 60 * 1000
module.exports = {
   help: ['checklink'],
   tags: 'owner',
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      conn.checklink = conn.checklink || {}
      if (args[0] === 'stop') {
         if (!conn.checklink[m.sender]) return conn.reply(m.chat, Func.texted('bold', ' Tidak ada sesi checklink yang aktif'), m)
         clearTimeout(conn.checklink[m.sender].timeout)
         delete conn.checklink[m.sender]
         conn.reply(m.chat, Func.texted('bold', ` Sesi berhasil dihapus.`), m)
      }
      if (conn.checklink[m.sender]) return conn.reply(m.chat, `🚩 Kamu sudah memiliki sesi aktif, kirim hingga 10 link grup atau kirim *${usedPrefix}checklink stop* untuk membatalkan sesi.`, m)
      let timeout = setTimeout(() => {
         delete conn.checklink[m.sender]
         conn.reply(m.chat, Func.texted('bold', ` Sesi checklink otomatis dihapus dalam waktu 2 menit, karena tidak ada aktivitas.`), m)
      }, TIMEOUT)
      conn.checklink[m.sender] = {
         id: Func.makeId(15),
         links: [],
         timeout
      }
      return conn.reply(m.chat, `Session checklink berhasil dibuat, kirim link grup max 100 / kirim *${usedPrefix + command} stop* untuk menghapus session.\n\nID : ${conn.checklink[m.sender].id}`, m)
   },
   limit: true,
   private: true,
}