const fetch = require('node-fetch')

module.exports = {
  help: ['donasi'],
  tags: ['info'],
  command: /^dona(te|si)$/i,

  run: async (m, { conn }) => {
    try {

      let teks = `💰 *DONASI BOT*

❒ Gopay / Dana / OVO:
6289530656600

❒ Link Dana:
https://link.dana.id/minta/xxxxxxxx

Terima kasih 🙏`

      // 🔥 ambil gambar jadi buffer
      let res = await fetch('https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg')
      let buffer = await res.buffer()

      await conn.sendMessage(m.chat, {
        image: buffer,
        caption: teks
      }, { quoted: m })

    } catch (e) {
      conn.reply(m.chat, '❌ Gagal kirim donasi\n' + e, m)
    }
  }
}