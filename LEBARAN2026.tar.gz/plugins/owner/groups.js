const moment = require('moment-timezone')
moment.tz.setDefault(process.env.TZ).locale('id')
module.exports = {
   help: ['groups'],
   tags: ['miscs'],
   run: async (m, {
      conn,
      usedPrefix,
      Func
   }) => {
      let groups = Object.entries(await conn.groupFetchAllParticipating()).map(entry => entry[1]).filter(group => !group.isCommunity)
      let caption = `乂  *G R O U P - L I S T*\n\n`
      caption += `*“Bot has joined into ${groups.length} groups, send _${usedPrefix}gc_ or _${usedPrefix}gcopt_ to show all setup options.”*\n\n`
      groups.map((x, i) => {
         let v = global.db.groups[x.id]
         if (!v) {
            global.db.groups[x.id] = {
               activity: new Date * 1
            }
            v = global.db.groups[x.id]
         }
         caption += `›  *${(i + 1)}.* ${x.subject}\n`
         caption += `   *💳* : ${x.id.split`@`[0]}\n\n`
      })
      caption += `${global.footer}`
      m.reply(caption)
   }
}