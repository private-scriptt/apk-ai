module.exports = {
   help: ['kickall'],
   use: 'not admin',
   tags: 'owner',
   run: async (m, {
      conn,
      Func
   }) => {
      try {
         const metadata = await conn.groupMetadata(m.chat)
         const botNumber = await conn.decodeJid(conn.user.id)
         const adminIds = metadata.participants.filter(p => p.admin).map(p => p.id)
         const toKick = metadata.participants.filter(p => !p.admin && p.id !== botNumber).map(p => p.id)
         if (toKick.length === 0) return m.reply(' Tidak ada member biasa yang bisa dikeluarkan.')
         m.reply(` Mengeluarkan ${toKick.length} member biasa dari grup...`)
         for (const id of toKick) {
            try {
               await conn.groupParticipantsUpdate(m.chat, [id], 'remove')
               console.log(` Keluarkan: ${id}`);
               await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 2000) + 3000))
            } catch (e) {
               console.error(` Gagal keluarkan ${id}:`, e);
            }
         }
         m.reply(` Selesai mengeluarkan semua member biasa.`)
      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   group: true,
   admin: true,
   botAdmin: true,
}