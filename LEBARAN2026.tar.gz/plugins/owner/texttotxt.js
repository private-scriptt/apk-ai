module.exports = {
   help: ['totxt'],
   tags: ['converter'],
   run: async (m, {
      conn,
      participants,
      isAdmin,
      isBotAdmin,
      Func,
      text
   }) => {
      if (!isAdmin) return m.reply(Func.texted('bold', 'Lu bukan admin.'))
      if (!isBotAdmin) return m.reply(Func.texted('bold', 'Jadiin bot admin dulu.'))
      
      let content = ''
      let fileName = ''

      // Parse parameter
      let [name, ...textParts] = text.split('|').map(v => v.trim())
      
      if (m.quoted) {
         // Jika reply pesan, ambil teks dari yang di reply
         if (m.quoted.text) {
            content = m.quoted.text
         } else if (m.quoted.caption) {
            content = m.quoted.caption
         } else {
            return m.reply(Func.texted('bold', 'Tidak ada teks dalam pesan yang di reply.'))
         }
         
         fileName = name ? `${name}.txt` : 'document.txt'
         
      } else {
         // Jika tidak reply, ambil dari parameter
         if (!name) {
            return m.reply(Func.texted('bold', 'Gunakan format:\n.totxt nama_file|teks\nAtau reply pesan: .totxt nama_file'))
         }
         
         content = textParts.join('|') // Gabung kembali jika ada pipe di teks
         fileName = `${name}.txt`
      }

      if (!content) {
         return m.reply(Func.texted('bold', 'Tidak ada konten untuk dibuat file TXT.'))
      }

      try {
         // Kirim file TXT
         await conn.sendMessage(m.chat, {
            document: Buffer.from(content),
            mimetype: 'text/plain',
            fileName: fileName
         }, { quoted: m })

      } catch (e) {
         console.error(e)
         return m.reply(Func.texted('bold', 'Error membuat file TXT.'))
      }
   },
   group: true,
   admin: true,
   botAdmin: true,
   owner: true
}