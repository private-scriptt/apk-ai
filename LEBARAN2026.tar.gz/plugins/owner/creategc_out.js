module.exports = {
   help: ['creategroup-out'],
   command: ['creategc-out'],
   use: 'no | name | amount | ephe | opt | opt',
   tags: 'owner',
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      try {
         if (args.length < 3) return m.reply(` Format salah! Gunakan:\n/creategroup <nomoradmin> | <NamaGroupAngkaUrutan> | <JumlahGroup> | [Timer (hari)] | [GroupInfo (on/off)] | [KirimPesan (on/off)]\n\nContoh:\n${usedPrefix + command} 6281234567890 | Group WS | 5 | 7 | off | off`);

         let [nomor, groupBaseName, jumlahGroup, timer, groupInfo, kirimPesan] = args.join(" ").split("|").map(v => v.trim());
         jumlahGroup = parseInt(jumlahGroup);
         timer = parseInt(timer) || 0;
         groupInfo = groupInfo?.toLowerCase() === 'on' ? 'unlocked' : 'locked';
         kirimPesan = kirimPesan?.toLowerCase() === 'on' ? 'not_announcement' : 'announcement';

         if (isNaN(jumlahGroup) || jumlahGroup < 1) return m.reply(" Jumlah grup harus angka dan minimal 1!");

         let createdGroups = [];

         for (let i = 1; i <= jumlahGroup; i++) {
            let groupName = `${groupBaseName} ${i}`;
            let participants = [nomor + '@s.whatsapp.net'];

            // **Buat grup**
            let group = await conn.groupCreate(groupName, participants);
            let groupId = group.id;

            // **Atur pengaturan grup**
            await conn.groupSettingUpdate(groupId, groupInfo);
            await conn.groupSettingUpdate(groupId, kirimPesan);

            // **Jadikan nomor sebagai admin**
            await conn.groupParticipantsUpdate(groupId, [nomor + '@s.whatsapp.net'], "promote").then(() => console.log(` ${nomor} berhasil dijadikan admin di grup ${groupName}`)).catch((err) => console.error(` Gagal menjadikan admin:`, err));

            // **Atur ephemeral messages jika ada**
            if ([1, 7, 90].includes(timer)) {
               await conn.sendMessage(groupId, {
                  disappearingMessagesInChat: timer * 24 * 60 * 60
               });
               console.log(`Ephemeral messages diaktifkan untuk ${timer} hari di grup ${groupName}`);
            }

            // **Dapatkan link undangan grup**
            let inviteCode = await conn.groupInviteCode(groupId);
            let groupLink = `https://chat.whatsapp.com/${inviteCode}`;
            createdGroups.push(`• *${groupName}*\n📎 ${groupLink}`);

            console.log(` Grup ${groupName} berhasil dibuat! Link: ${groupLink}`);

            // *Bot keluar dari grup*
            await conn.groupLeave(groupId)
            .then(() => console.log(` Bot keluar dari grup ${groupName}`))
            .catch((err) => console.error(`❌ Gagal keluar dari grup:`, err));

            // **Delay 8 detik sebelum membuat grup berikutnya**
            if (i < jumlahGroup) {
               console.log(` Menunggu 8 detik sebelum membuat grup berikutnya...`);
               await Func.delay(8000);
            }
         }

         // **Kirim daftar grup beserta linknya**
         m.reply(` Berhasil membuat ${createdGroups.length} grup:\n\n${createdGroups.join("\n\n")}`);

      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   owner: true,
}