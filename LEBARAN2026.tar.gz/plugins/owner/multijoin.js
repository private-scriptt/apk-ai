const TIMEOUT = 2 * 60 * 1000
module.exports = {
   help: ['multijoin'],
   tags: 'owner',
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      conn.multijoin = conn.multijoin || {}
      if (args[0] === 'stop') {
         if (!conn.multijoin[m.sender]) return conn.reply(m.chat, Func.texted('bold', '🚩 Tidak ada sesi multijoin yang aktif'), m)
         clearTimeout(conn.multijoin[m.sender].timeout)
         delete conn.multijoin[m.sender]
         conn.reply(m.chat, Func.texted('bold', `✅ Sesi berhasil dihapus.`), m)
      }
      if (conn.multijoin[m.sender]) return conn.reply(m.chat, `🚩 Kamu sudah memiliki sesi aktif, kirim hingga 50 link grup atau kirim *${usedPrefix}multijoin stop* untuk membatalkan sesi.`, m)
      let timeout = setTimeout(() => {
         delete conn.multijoin[m.sender]
         conn.reply(m.chat, Func.texted('bold', `🚩 Sesi multijoin otomatis dihapus dalam waktu 2 menit, karena tidak ada aktivitas.`), m)
      }, TIMEOUT)
      conn.multijoin[m.sender] = {
         id: Func.makeId(15),
         links: [],
         timeout
      }
      return conn.reply(m.chat, `Session multijoin berhasil dibuat, kirim link grup max 10 / kirim *${usedPrefix + command} stop* untuk menghapus session.\n\nID : ${conn.multijoin[m.sender].id}`, m)
   },
   limit: true,
   private: true,
}