module.exports = {
  help: ['harga'],
  tags: ['info'],
  command: /^dona(te|si)$/i,

  run: async (m, { conn }) => {
    try {

      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            amount: {
              value: 100000000,
              offset: 0,
              currencyCode: 'IDR'
            },
            amount1000: 100000000,
            background: null,
            currencyCodeIso4217: 'IDR',
            expiryTimestamp: 0,
            noteMessage: {
              extendedTextMessage: {
                text: `❒ Gopay : 6289530656600
❒ Ovo   : 6289530656600
❒ Pulsa : 6289530656600

Note : Donasi Seikhlasnya, Agar Bot Dapat Beroperasi Lebih Lama Dan Supaya Owner Semangat Untuk Menambah Fitur² Baru, Dan Memperbaiki Fitur² Yang Error

Sekian *MATUR NUWUN*

Dōmo arigatōgozaimasu ~`
              }
            },
            requestFrom: m.sender
          }
        },
        { messageId: m.key.id }
      )

    } catch (e) {
      conn.reply(m.chat, '❌ Gagal kirim donasi\n' + e, m)
    }
  }
}