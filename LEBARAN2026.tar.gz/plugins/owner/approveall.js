module.exports = {
   help: ['approveall'],
   tags: 'owner',
   run: async (m, { conn, usedPrefix, command, args, Func }) => {
      try {
         let groups = await conn.groupFetchAllParticipating();
         let groupIds = Object.keys(groups);
         let success = 0;
         let failed = 0;

         for (let id of groupIds) {
            let metadata = groups[id];
            const isBotAdmin = metadata.participants.find(p => p.id === conn.user.id)?.admin;
            if (!isBotAdmin) {
               failed++;
               continue;
            }

            try {
               await conn.groupSettingUpdate(id, 'approval_mode'); // aktifkan
               success++;
            } catch {
               failed++;
            }
         }

         m.reply(` Berhasil mengaktifkan persetujuan anggota di ${success} grup.\n Gagal diaktifkan di ${failed} grup.`);
      } catch (err) {
         console.error(err);
         m.reply('Terjadi kesalahan saat mengaktifkan fitur.');
      }
   },
   owner: true,
}