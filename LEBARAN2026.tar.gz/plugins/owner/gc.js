module.exports = {
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      try {
         if (m.quoted && (m.quoted.text).match(/gcopt/g) && m.quoted.sender == conn.decodeJid(conn.user.id)) {
            if (!args || !args[0]) return m.reply(Func.texted('bold', `🚩 Berikan argumen nomor grup secara berurutan.`))
            if (isNaN(args[0])) return m.reply(Func.texted('bold', `🚩 Argumen ini harus berupa angka.`))
            const jids = (m.quoted.text).split('💳* :').length
            if (args[0] > (jids - 1) || args[0] < 1) return m.reply(Func.texted('bold', `🚩 Terjadi kesalahan, silakan periksa kembali daftar data grup.`))
            const select = (args[0]).trim()
            const jid = ((m.quoted.text).split('💳* :')[select].split`\n`[0] + '@g.us').trim()
            const group = global.db.groups[jid]
            if (!group) return m.reply(Func.texted('bold', `🚩 Grup data tidak ada dalam database.`))
            const groupMetadata = await (await conn.groupMetadata(jid))
            const req = await conn.groupRequestParticipantsList(jid)
            const groupName = groupMetadata ? groupMetadata.subject : ''
            const adminList = await conn.groupAdmin(jid)
            const admin = adminList.includes((conn.user.id.split`:`[0]) + '@s.whatsapp.net')
            const useOpt = (args && args[1]) ? true : false
            const option = useOpt ? (args[1]).toLowerCase() : false
            if (option == 'open') {
               if (!admin) return conn.reply(m.chat, Func.texted('bold', `🚩 Can't open ${groupName} group link because the bot is not an admin.`), m)
               conn.groupSettingUpdate(jid, 'not_announcement').then(() => {
                  conn.reply(jid, Func.texted('bold', `🚩 Group has been opened.`)).then(() => {
                     conn.reply(m.chat, Func.texted('bold', `🚩 Successfully open ${groupName} group.`), m)
                  })
               })
            } else if (option == 'close') {
               if (!admin) return conn.reply(m.chat, Func.texted('bold', `🚩 Can't close ${groupName} group link because the bot is not an admin.`), m)
               conn.groupSettingUpdate(jid, 'announcement').then(() => {
                  conn.reply(jid, Func.texted('bold', `🚩 Group has been closed.`)).then(() => {
                     conn.reply(m.chat, Func.texted('bold', `🚩 Successfully close ${groupName} group.`), m)
                  })
               })
            } else if (option == 'link') {
               if (!admin) return conn.reply(m.chat, Func.texted('bold', `🚩 Can't get ${groupName} group link because the bot is not an admin.`), m)
               conn.reply(m.chat, 'https://chat.whatsapp.com/' + (await conn.groupInviteCode(jid)), m)
            } else if (option == 'leave') {
               conn.reply(m.chat, Func.texted('bold', `🚩 Successfully leave from ${groupName} group.`), m)
            } else if (option == 'acc-list') {
               let req = await conn.groupRequestParticipantsList(jid)
               conn.reply(m.chat, `Daftar permintaan bergabung\n\n${req.length > 0 ? req.map((request, i) => {
                  return `*${i + 1}.*\n- Nomor : ${request.jid.split('@')[0]}\n- Metode Permintaan : ${request.request_method}\n- Waktu Permintaan : ${((timestamp = request.request_time),
                     new Intl.DateTimeFormat('id-ID', {
                        weekday: 'long',
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                     }).format(new Date(1e3 * timestamp)))}`
               }).join('') : 'Tidak ada permintaan bergabung yang tertunda.'}`, m)
            } else if (option == 'acc-approve') {
               for (let request of req) await conn.groupRequestParticipantsUpdate(jid, [request.jid], 'approve')
               m.reply(Func.texted('bold', `🚩 Berhasil menyetujui semua member.`))
            } else if (option == 'acc-reject') {
               for (let request of req) await conn.groupRequestParticipantsUpdate(jid, [request.jid], 'reject')
               m.reply(Func.texted('bold', `🚩 Berhasil menolak semua member.`))
            } else if (option == 'kick-1') {
               let botNumber = await conn.decodeJid(conn.user.id)
               let toKick = groupMetadata.participants.filter(p => !p.admin && p.id !== botNumber).map(p => p.id)
               if (toKick.length === 0) return m.reply(Func.texted('bold', `🚩 Tidak ada member yang bisa dikeluarkan.`))
               m.react('🕒')
               for (const id of toKick) {
                  try {
                     await conn.groupParticipantsUpdate(m.chat, [id], 'remove')
                     console.log(`🚩 Mengeluarkan : ${id}`)
                     await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 2000) + 3000))
                  } catch (e) {
                     console.error(e)
                     m.reply(Func.jsonFormat(e))
                  }
               }
               m.reply(Func.texted('bold', `🚩 Berhasil mengeluarkan semua member kecuali Admin.`))
            } else if (option == 'kick-2') {
               let botNumber = await conn.decodeJid(conn.user.id)
               let toKick = groupMetadata.participants.filter(p => p.id !== botNumber).map(p => p.id)
               if (toKick.length === 0) return m.reply(Func.texted('bold', `🚩 Tidak ada member yang bisa dikeluarkan.`))
               for (const id of toKick) {
                  try {
                     await conn.groupParticipantsUpdate(m.chat, [id], 'remove')
                     console.log(`🚩 Mengeluarkan : ${id}`)
                     await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 2000) + 3000))
                  } catch (e) {
                     console.error(e)
                     m.reply(Func.jsonFormat(e))
                  }
               }
               m.reply(Func.texted('bold', `🚩 Berhasil mengeluarkan semua member termasuk Admin.`))
            } else return m.reply(explain(usedPrefix, command))
         } else return m.reply(explain(usedPrefix, command))
      } catch (e) {
         console.log(e)
         m.reply(Func.jsonFormat(e))
      }
   },
   help: ['gc'],
   command: ['gcopt'],
   use: '(option)',
   tags: 'owner',
   owner: true
}

const explain = (prefix, cmd) => {
   return `乂  *M O D E R A T I O N*

 *1.* ${prefix + cmd} <no> open
 - untuk membuka grup yang memungkinkan semua anggota mengirim pesan

 *2.* ${prefix + cmd} <no> close
 - untuk menutup grup, hanya admin yang dapat mengirim pesan

 *3.* ${prefix + cmd} <no> link
 - untuk mendapatkan tautan undangan grup, pastikan bot adalah admin

 *4.* ${prefix + cmd} <no> leave
 - untuk meninggalkan grup

 *5.* ${prefix + cmd} <no> acc-list
 - menampilkan jumlah permintaan bergabung

 *6.* ${prefix + cmd} <no> acc-approve
 - menyetujui semua permintaan bergabung

 *7.* ${prefix + cmd} <no> acc-reject
 - menolak semua permintaan bergabung

 *8.* ${prefix + cmd} <no> kick-1
 - mengeluarkan semua member, kecuali Admin

 *9.* ${prefix + cmd} <no> kick-2
 - mengeluarkan semua member, termasuk Admin

 *NB* : Pastikan Kamu membalas pesan yang berisi daftar grup untuk menggunakan opsi moderasi ini, kirimkan _${prefix}groups_ untuk menampilkan semua daftar grup.`
}