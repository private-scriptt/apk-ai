module.exports = {
   help: ['addvcf'],
   tags: ['owner'],
   run: async (m, {
      conn,
      participants,
      isAdmin,
      isBotAdmin,
      Func
   }) => {
      if (!isAdmin) return m.reply(Func.texted('bold', '🚩 Lu bukan admin.'))
      if (!isBotAdmin) return m.reply(Func.texted('bold', '🚩 Jadiin bot admin dulu.'))
      if (!m.quoted) return m.reply(Func.texted('bold', '🚩 Reply file VCF-nya.'))

      try {
         let mime = m.quoted.mimetype || ''
         if (!/text\/vcard|text\/x-vcard|application\/vcard/.test(mime) && !m.quoted.msg?.vcard) {
            return m.reply(Func.texted('bold', '🚩 Itu bukan file VCF.'))
         }

         m.reply(Func.texted('bold', '🔄 Mengurai kontak & Memproses satu-persatu...'))

         let buffer = await m.quoted.download()
         let vcfText = buffer.toString()

         let rawNumbers = vcfText.match(/TEL;[^:]+:?([+0-9\s-]+)/gi)
         if (!rawNumbers || !rawNumbers.length) return m.reply(Func.texted('bold', '🚩 Kosong, ga ada nomor.'))

         let defaultCode = '62'

         let targetParticipants = rawNumbers.map(v => {
            let raw = v.replace(/TEL;[^:]+:?/gi, '').replace(/[\s\-\(\)]/g, '')
            let clean = ''
            if (raw.startsWith('+')) clean = raw.substring(1)
            else if (raw.startsWith('0')) clean = defaultCode + raw.substring(1)
            else clean = raw
            return clean + '@s.whatsapp.net'
         }).filter((v, i, a) => a.indexOf(v) === i)

         // --- EKSEKUSI SATU-SATU (REAL DELAY) ---
         let success = 0
         let failed = 0

         for (let user of targetParticipants) {
            try {
               // Add 1 orang
               let res = await conn.groupParticipantsUpdate(m.chat, [user], 'add')

               // Cek status code (200/201 = sukses, 403 = gagal/privasi)
               if (res[0]?.status == '200' || res[0]?.status == '201') {
                  success++
               } else {
                  failed++
               }
            } catch (e) {
               console.error(e)
               failed++
            }

            // JEDA 5 DETIK SETIAP 1 ORANG
            // Ubah angka 5000 jadi 10000 kalau mau 10 detik
            await Func.delay(5000)
         }

         m.reply(`✅ *DONE*\n\n🔰 Total: ${targetParticipants.length}\n✅ Masuk: ${success}\n❌ Gagal: ${failed}`)

      } catch (e) {
         console.error(e)
         return m.reply(Func.texted('bold', '🚩 Error parsing VCF.'))
      }
   },
   group: true,
   admin: true,
   botAdmin: true,
   owner: true
}