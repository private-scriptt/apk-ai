module.exports = {
   help: ['getlink'],
   tags: 'owner',
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      Func
   }) => {
      try {
         // Ambil semua grup tempat bot tergabung
         let groups = Object.entries(await conn.groupFetchAllParticipating())
         if (!groups.length) return conn.reply(m.chat, Func.texted('bold', '🚩 Bot tidak tergabung dalam grup manapun.'), m)

         m.react('🕒')
         let teks = '', total = 0, sukses = 0, gagal = 0

         // Proses untuk setiap grup
         for (let [id, info] of groups) {
            total++
            try {
               let groupId = id
               let groupMeta = await conn.groupMetadata(groupId).catch(() => null)

               // Cek apakah metadata grup berhasil diambil
               if (!groupMeta) throw new Error('Gagal mengambil metadata grup')

               let name = groupMeta?.subject || info?.subject || 'No Name'
               let botJid = conn.decodeJid(conn.user.id || conn.user.jid)

               // Cek apakah bot admin di grup tersebut
               let botParticipant = groupMeta.participants.find(p => p.id === botJid)
               if (!botParticipant || !botParticipant.admin) {
                  throw new Error('Bot bukan admin di grup ini')
               }

               // Coba ambil link undangan grup
               let code = await conn.groupInviteCode(groupId)
               if (!code) throw new Error('Link undangan undefined')

               // Menambahkan hasil sukses
               teks += `• https://chat.whatsapp.com/${code} : ( ${name} )\n`
               sukses++
            } catch (e) {
               // Menambahkan hasil gagal dengan alasan error
               let name = info?.subject || 'No Name'
               teks += `• Gagal (${e.message}) : ( ${name} )\n`
               gagal++
            }
            await Func.delay(1500) // Delay 1.5 detik agar tidak terlalu cepat
         }

         // Ringkasan hasil
         teks += `\nRingkasan\n• Total : ${total}\n• Berhasil : ${sukses}\n• Gagal : ${gagal}`

         // Kirim hasil akhir ke chat
         m.reply(teks.trim())
      } catch (e) {
         console.log(e)
         conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   owner: true
}