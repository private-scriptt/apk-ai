module.exports = {
   run: async (m, {
      conn,
      body,
      users,
      prefixes,
      Func,
      Scraper
   }) => {
      try {
         /** checking session */
         conn.checklink = conn.checklink || {}
         if (!conn.checklink[m.sender]) return
         let session = conn.checklink[m.sender]
         let links = [...m.text.matchAll(/https?:\/\/chat\.whatsapp\.com\/([0-9A-Za-z]+)/g)].map(v => v[0])

         /** filter */
         if (!links.length) return
         if (session.links?.length + links.length > 100) return conn.reply(m.chat, Func.texted('bold', '🚩 Max 100 link per session.'), m)
         session.links = session.links || []
         session.links.push(...links)
         clearTimeout(session.timeout)

         /** hapus session otomatis */
         session.timeout = setTimeout(() => {
            delete conn.checklink[m.sender]
            conn.reply(m.chat, Func.texted('bold', `🚩 Sesi checklink otomatis dihapus dalam waktu 2 menit, karena tidak ada aktivitas.`), Func.fake(1, 'Asep♡Ima Bot WhatsApp'))
         }, 2 * 60 * 1000)

         /** masuk proses */
         let results = []
         for (let link of links) {
            let code = link.split('/').pop()
            try {
               let info = await conn.groupGetInviteInfo(code)
               results.push(`*Status* : °\n*Link* : ${link}\n*Name* : ${info.subject}`)
            } catch (e) {
               results.push(`*Status* : •\n*Link* : ${link}\n*Error* : ${e.message || 'Not Found'}`)
            }
            await (Func.delay ? Func.delay(600) : new Promise(res => setTimeout(res, 600)))
         }

         /** mengirim hasil */
         return m.reply(results.join('\n\n'))
      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   private: true
}