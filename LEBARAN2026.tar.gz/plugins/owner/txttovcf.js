module.exports = {
   help: ['tovcf'],
   tags: ['converter'],
   run: async (m, {
      conn,
      participants,
      isAdmin,
      isBotAdmin,
      Func,
      text
   }) => {
      if (!isAdmin) return m.reply(Func.texted('bold', 'Lu bukan admin.'))
      if (!isBotAdmin) return m.reply(Func.texted('bold', 'Jadiin bot admin dulu.'))
      if (!m.quoted) return m.reply(Func.texted('bold', 'Reply file TXT-nya.'))

      // Parse parameter
      let [contactName, fileCount, perFile] = text.split('|').map(v => v.trim())
      
      if (!contactName) {
         return m.reply(Func.texted('bold', 'Gunakan format: .tovcf nama | jumlah_file | jumlah_nomor\nContoh: .tovcf asep | 3 | 50'))
      }
      
      fileCount = parseInt(fileCount) || 1
      perFile = parseInt(perFile) || 50
      
      if (fileCount < 1) fileCount = 1
      if (perFile < 1) perFile = 50
      if (perFile > 500) perFile = 500 // Maksimal 500 per file biar ga kegedean

      try {
         // Cek format file
         let mime = m.quoted.mimetype || ''
         if (!/text\/plain/.test(mime)) {
            return m.reply(Func.texted('bold', 'Itu bukan file TXT.'))
         }

         m.reply(Func.texted('bold', 'Membaca file TXT...'))

         let buffer = await m.quoted.download()
         let txtText = buffer.toString()

         // Split per baris dan bersihkan
         let lines = txtText.split('\n')
            .map(line => line.trim())
            .filter(line => line && line.length > 0)

         if (!lines.length) return m.reply(Func.texted('bold', 'File TXT kosong.'))

         // Bersihkan nomor terlebih dahulu
         let validNumbers = []
         for (let line of lines) {
            let cleanNumber = line.replace(/[^\d+]/g, '')
            if (cleanNumber) {
               validNumbers.push(cleanNumber)
            }
         }

         if (!validNumbers.length) {
            return m.reply(Func.texted('bold', 'Tidak ada nomor valid dalam file TXT.'))
         }

         m.reply(`Total ${validNumbers.length} nomor\nMembuat ${fileCount} file @ ${perFile} nomor per file...`)

         // Buat file VCF per bagian
         let currentIndex = 0
         let fileNumber = 1
         
         while (currentIndex < validNumbers.length && fileNumber <= fileCount) {
            let endIndex = Math.min(currentIndex + perFile, validNumbers.length)
            let batchNumbers = validNumbers.slice(currentIndex, endIndex)
            
            let vcfContent = ''
            let contactCounter = 1
            
            for (let number of batchNumbers) {
               vcfContent += 'BEGIN:VCARD\n'
               vcfContent += 'VERSION:3.0\n'
               vcfContent += `FN:${contactName} ${currentIndex + contactCounter}\n`
               vcfContent += `TEL;TYPE=CELL:${number}\n`
               vcfContent += 'END:VCARD\n\n'
               contactCounter++
            }

            // Kirim file VCF
            let fileName = `${contactName}_bagian${fileNumber}.vcf`
            
            await conn.sendMessage(m.chat, {
               document: Buffer.from(vcfContent),
               mimetype: 'text/x-vcard',
               fileName: fileName
            }, { quoted: m })

            currentIndex = endIndex
            fileNumber++
            
            // Delay antar pengiriman file
            if (currentIndex < validNumbers.length && fileNumber <= fileCount) {
               await Func.delay(2000)
            }
         }

         m.reply(`Selesai! ${validNumbers.length} nomor`)

      } catch (e) {
         console.error(e)
         return m.reply(Func.texted('bold', 'Error processing TXT file.'))
      }
   },
   group: true,
   admin: true,
   botAdmin: true,
   owner: true
}