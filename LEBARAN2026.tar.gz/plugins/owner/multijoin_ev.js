module.exports = {
   run: async (m, {
      conn,
      body,
      users,
      prefixes,
      Func,
      Scraper
   }) => {
      try {
         conn.multijoin = conn.multijoin || {}
         if (!conn.multijoin[m.sender]) return
         let session = conn.multijoin[m.sender]

         // Ambil semua link dari pesan
         let links = [...m.text.matchAll(/https?:\/\/chat\.whatsapp\.com\/([0-9A-Za-z]+)/g)].map(v => v[0])
         if (!links.length) return

         // Batas total link dalam satu sesi
         if ((session.links?.length || 0) + links.length > 50) return conn.reply(m.chat, Func.texted('bold', '🚩 Maksimal 50 link per sesi.'), m)

         session.links = session.links || []
         session.links.push(...links)
         clearTimeout(session.timeout)

         // Reset timeout sesi 2 menit jika ada aktivitas
         session.timeout = setTimeout(() => {
            delete conn.multijoin[m.sender]
            conn.reply(m.chat, Func.texted('bold', `🚩 Sesi multijoin otomatis dihapus karena tidak ada aktivitas selama 2 menit.`), m)
         }, 2 * 60 * 1000)

         // Mulai proses join
         let sukses = []
         let gagal = []

         for (let link of links) {
            let code = link.split('/').pop().trim()
            try {
               let groupId = await conn.groupAcceptInvite(code)
               let metadata = await conn.groupMetadata(groupId)
               sukses.push(metadata.subject)
               await Func.delay(1500) // Delay 1,5 detik antar join
            } catch (e) {
               gagal.push({
                  link,
                  reason: e.message || 'Gagal join'
               })
            }
         }

         // Kirim hasil
         let text = `Result join grup\n\n`
         text += `✅ Berhasil ( ${sukses.length} ) :\n${sukses.map((v, i) => `${i + 1}. ${v}`).join('\n') || '-'}\n\n`
         text += `❌ Gagal ( ${gagal.length} ):\n${gagal.map((v, i) => `${i + 1}. ${v.link} (${v.reason})`).join('\n') || '-'}`

         return m.reply(text)
      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   private: true
} 