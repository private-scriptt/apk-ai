module.exports = {
   help: ['leaveall'],
   tags: 'owner',
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      try {
         // Ambil semua grup yang diikuti bot
         const groups = await conn.groupFetchAllParticipating();

         let count = 0;
         for (let id in groups) {
            try {
               await conn.groupLeave(id);
               count++;
            } catch (err) {
               console.log(`Gagal keluar dari grup: ${id}`, err);
            }
         }

         m.reply(`Berhasil keluar dari ${count} grup.`);
      } catch (err) {
         console.error(err);
         m.reply('Terjadi kesalahan saat mencoba keluar dari grup.');
      }
   },
   limit: true,
   private: true,
}