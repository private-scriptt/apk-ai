module.exports = {
   help: ['promoteadmin'],
   tags: 'owner',
   owner: true,
   run: async (m, { conn, args, usedPrefix, command, Func }) => {
      if (!args[0]) {
         return conn.reply(m.chat, Func.example(usedPrefix, command, '6281xxxxxx'), m)
      }

      // Normalisasi nomor target
      let number = normalizeNumber(args[0])
      if (!number) return conn.reply(m.chat, ' Nomor tidak valid.', m)
      let jid = number + '@s.whatsapp.net'

      // Ambil semua grup
      let groups = Object.values(await conn.groupFetchAllParticipating())
      if (!groups.length) return conn.reply(m.chat, ' Bot tidak tergabung di grup mana pun.', m)

      // Ambil JID bot sendiri dalam format yang cocok dengan peserta grup
      let botJid = conn.decodeJid(conn.user?.id || conn.user?.jid)

      let hasil = {
         sukses: [],
         gagal: []
      }

      for (let g of groups) {
         try {
            let metadata = g

            // Pastikan data lengkap
            if (!metadata?.participants) {
               hasil.gagal.push({ group: metadata.subject || g.id, alasan: 'data grup tidak lengkap' })
               continue
            }

            // Cek apakah bot admin
            let bot = metadata.participants.find(p => p.id === botJid)
            if (!bot?.admin) {
               continue // skip grup yang bot bukan admin
            }

            // Cek apakah target ada di grup
            let target = metadata.participants.find(p => p.id === jid)
            if (!target) {
               continue // skip grup jika target belum masuk
            }

            // Jika target sudah admin
            if (target.admin) {
               hasil.gagal.push({ group: metadata.subject, alasan: 'sudah admin' })
               continue
            }

            // Promote
            await conn.groupParticipantsUpdate(metadata.id, [jid], 'promote')
            hasil.sukses.push(metadata.subject)
            await Func.delay(1000)

         } catch (e) {
            hasil.gagal.push({ group: g.subject || g.id, alasan: e.message || 'gagal promote' })
         }
      }

      // Tampilkan hasil
      let teks = `📋 *Hasil Promote Admin*\n\n`
      teks += `• *Berhasil* (${hasil.sukses.length})\n`
      teks += hasil.sukses.map((v, i) => `${i + 1}. ${v}`).join('\n') || '-'
      teks += `\n\n° *Gagal* (${hasil.gagal.length})\n`
      teks += hasil.gagal.map((v, i) => `${i + 1}. ${v.group} (${v.alasan})`).join('\n') || '-'

      return conn.reply(m.chat, teks, m)
   }
}

// Fungsi normalisasi nomor
function normalizeNumber(input) {
   let num = input.replace(/[^0-9]/g, '')
   if (num.length < 8) return null
   if (num.startsWith('0')) num = '62' + num.slice(1)
   if (!num.startsWith('62')) num = '62' + num
   return num
}
